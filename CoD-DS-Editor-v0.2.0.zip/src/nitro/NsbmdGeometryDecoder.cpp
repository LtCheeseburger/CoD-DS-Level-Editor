#include "NsbmdGeometryDecoder.hpp"

#include "core/Logger.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iterator>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_set>

#include <QMatrix4x4>
#include <QVector4D>

// ============================================================================
// NDS GX Display-List Decoder  v0.2.0
// ============================================================================
//
// Key corrections vs v0.1.x:
//
//   1. MDL0 polygon-table walking  — display-list regions are now located by
//      following MDL0 → model-table → polygon-table instead of scanning for
//      BEGIN_VTXS heuristically.  This eliminates false-positive regions.
//
//   2. VTX_DIFF scale  — NDS HW manual §4.6.11: 10-bit signed delta is in
//      units of 1/(4096*8), NOT 1/4096.  Previous code used kFx12 (=1/4096),
//      producing deltas 8× too large which stretched geometry.
//
//   3. Matrix transpose  — NDS GX stores matrices column-major; QMatrix4x4
//      is row-major.  All load helpers now transpose, so QMatrix4x4::map()
//      gives the correct hardware result.
//
//   4. MTX_POP signed count  — pop parameter is 6-bit *signed*.
//
//   5. Persistent vertex state  — currentLocal is updated on every vertex
//      command so VTX_XY/XZ/YZ/DIFF always reference the correct prior
//      position.
//
// ============================================================================

namespace nitro
{
    namespace
    {
        // ------------------------------------------------------------------ //
        //  Fixed-point constants                                              //
        // ------------------------------------------------------------------ //

        // NDS 1.11.4 fixed-point:  2^12 = 4096.
        constexpr float kFx12   = 1.0f / 4096.0f;

        // VTX_10: 1.3.6 fixed-point (6 fractional bits).
        constexpr float kFx6    = 1.0f / 64.0f;

        // VTX_DIFF: "1/8 of 1/4096" per HW manual §4.6.11.
        constexpr float kFxDiff = 1.0f / (4096.0f * 8.0f);

        constexpr std::size_t kMaxCommandWords = 262144;
        constexpr std::size_t kMaxVertices     = 200000;

        // ------------------------------------------------------------------ //
        //  Byte-level helpers                                                 //
        // ------------------------------------------------------------------ //

        bool canRead(const std::vector<uint8_t>& d, std::size_t off, std::size_t len)
        {
            return off <= d.size() && len <= d.size() - off;
        }

        uint16_t readU16(const std::vector<uint8_t>& d, std::size_t off)
        {
            return static_cast<uint16_t>(d[off]) |
                   (static_cast<uint16_t>(d[off+1]) << 8);
        }

        uint32_t readU32(const std::vector<uint8_t>& d, std::size_t off)
        {
            return static_cast<uint32_t>(d[off])          |
                   (static_cast<uint32_t>(d[off+1]) << 8)  |
                   (static_cast<uint32_t>(d[off+2]) << 16) |
                   (static_cast<uint32_t>(d[off+3]) << 24);
        }

        int32_t signExtend(uint32_t v, int bits)
        {
            const uint32_t mask = 1u << (bits - 1);
            v &= (1u << bits) - 1u;
            return static_cast<int32_t>((v ^ mask) - mask);
        }

        // 32-bit fixed-point word (1.11.4) → float.
        float fx12w(uint32_t raw)
        {
            return static_cast<float>(static_cast<int32_t>(raw)) * kFx12;
        }

        // 16-bit fixed-point half-word (s4.12 / 1.11.4 bottom half) → float.
        float fx12h(uint16_t raw)
        {
            return static_cast<float>(static_cast<int16_t>(raw)) * kFx12;
        }

        // ------------------------------------------------------------------ //
        //  GX command argument-word counts                                    //
        // ------------------------------------------------------------------ //

        int commandArgWords(uint8_t cmd)
        {
            switch (cmd)
            {
                case 0x00: return 0;
                case 0x10: return 1;   // MTX_MODE
                case 0x11: return 0;   // MTX_PUSH
                case 0x12: return 1;   // MTX_POP
                case 0x13: return 1;   // MTX_STORE
                case 0x14: return 1;   // MTX_RESTORE
                case 0x15: return 0;   // MTX_IDENTITY
                case 0x16: return 16;  // MTX_LOAD_4x4
                case 0x17: return 12;  // MTX_LOAD_4x3
                case 0x18: return 16;  // MTX_MULT_4x4
                case 0x19: return 12;  // MTX_MULT_4x3
                case 0x1A: return 9;   // MTX_MULT_3x3
                case 0x1B: return 3;   // MTX_SCALE
                case 0x1C: return 3;   // MTX_TRANS
                case 0x20: return 1;   // COLOR
                case 0x21: return 1;   // NORMAL
                case 0x22: return 1;   // TEXCOORD
                case 0x23: return 2;   // VTX_16
                case 0x24: return 1;   // VTX_10
                case 0x25: return 1;   // VTX_XY
                case 0x26: return 1;   // VTX_XZ
                case 0x27: return 1;   // VTX_YZ
                case 0x28: return 1;   // VTX_DIFF
                case 0x29: return 1;   // POLYGON_ATTR
                case 0x2A: return 1;   // TEXIMAGE_PARAM
                case 0x2B: return 1;   // PLTT_BASE
                case 0x30: return 1;   // DIF_AMB
                case 0x31: return 1;   // SPE_EMI
                case 0x32: return 1;   // LIGHT_VECTOR
                case 0x33: return 1;   // LIGHT_COLOR
                case 0x34: return 32;  // SHININESS
                case 0x40: return 1;   // BEGIN_VTXS
                case 0x41: return 0;   // END_VTXS
                case 0x50: return 1;   // SWAP_BUFFERS
                case 0x60: return 1;   // VIEWPORT
                case 0x70: return 3;   // BOX_TEST
                case 0x71: return 2;   // POS_TEST
                case 0x72: return 1;   // VEC_TEST
                default:   return -1;
            }
        }

        // ------------------------------------------------------------------ //
        //  Matrix helpers  (NDS column-major → QMatrix4x4 row-major)         //
        // ------------------------------------------------------------------ //
        //
        // NDS GX stores matrices column-major: word i belongs to
        //   col = i / rows,  row = i % rows.
        //
        // QMatrix4x4(m11,m12,...,m44) expects data row-by-row, and
        // QMatrix4x4::map(v) computes M*v.  We want the same M*v as the HW,
        // so we must transpose the NDS layout when loading into Qt.

        QMatrix4x4 matLoad4x4(const std::vector<uint8_t>& d, std::size_t pc)
        {
            float m[16];
            for (int i = 0; i < 16; ++i)
                m[i] = fx12w(readU32(d, pc + static_cast<std::size_t>(i)*4u));
            // Transpose: NDS m[col*4+row] → Qt row-major (row*4+col).
            return QMatrix4x4(
                m[ 0], m[ 4], m[ 8], m[12],
                m[ 1], m[ 5], m[ 9], m[13],
                m[ 2], m[ 6], m[10], m[14],
                m[ 3], m[ 7], m[11], m[15]);
        }

        QMatrix4x4 matLoad4x3(const std::vector<uint8_t>& d, std::size_t pc)
        {
            // 4 columns × 3 rows; row 3 is implicit (0,0,0,1).
            // NDS layout: c0r0,c0r1,c0r2, c1r0,c1r1,c1r2, ... c3r0,c3r1,c3r2
            float m[12];
            for (int i = 0; i < 12; ++i)
                m[i] = fx12w(readU32(d, pc + static_cast<std::size_t>(i)*4u));
            return QMatrix4x4(
                m[0], m[3], m[6], m[ 9],
                m[1], m[4], m[7], m[10],
                m[2], m[5], m[8], m[11],
                0.0f, 0.0f, 0.0f, 1.0f);
        }

        QMatrix4x4 matLoad3x3(const std::vector<uint8_t>& d, std::size_t pc)
        {
            float m[9];
            for (int i = 0; i < 9; ++i)
                m[i] = fx12w(readU32(d, pc + static_cast<std::size_t>(i)*4u));
            return QMatrix4x4(
                m[0], m[3], m[6], 0.0f,
                m[1], m[4], m[7], 0.0f,
                m[2], m[5], m[8], 0.0f,
                0.0f, 0.0f, 0.0f, 1.0f);
        }

        QMatrix4x4 matScale(const std::vector<uint8_t>& d, std::size_t pc)
        {
            QMatrix4x4 m; m.setToIdentity();
            m.scale(fx12w(readU32(d,pc)), fx12w(readU32(d,pc+4)), fx12w(readU32(d,pc+8)));
            return m;
        }

        QMatrix4x4 matTranslate(const std::vector<uint8_t>& d, std::size_t pc)
        {
            QMatrix4x4 m; m.setToIdentity();
            m.translate(fx12w(readU32(d,pc)), fx12w(readU32(d,pc+4)), fx12w(readU32(d,pc+8)));
            return m;
        }

        // ------------------------------------------------------------------ //
        //  Vertex / edge bookkeeping                                          //
        // ------------------------------------------------------------------ //

        bool plausibleVertex(const QVector3D& v)
        {
            return std::isfinite(v.x()) && std::isfinite(v.y()) && std::isfinite(v.z()) &&
                   std::abs(v.x()) < 100000.f &&
                   std::abs(v.y()) < 100000.f &&
                   std::abs(v.z()) < 100000.f;
        }

        uint64_t edgeKey(uint32_t a, uint32_t b)
        {
            if (a > b) std::swap(a, b);
            return (static_cast<uint64_t>(a) << 32) | b;
        }

        void addEdge(DecodedNsbmdMesh& mesh,
                     std::unordered_set<uint64_t>& edgeSet,
                     uint32_t a, uint32_t b)
        {
            if (a == b) return;
            if (edgeSet.insert(edgeKey(a,b)).second)
                mesh.edges.push_back({a, b});
        }

        bool validIdx(uint32_t idx) { return idx != UINT32_MAX; }

        void emitTriangle(DecodedNsbmdMesh& mesh,
                          std::unordered_set<uint64_t>& edgeSet,
                          uint32_t a, uint32_t b, uint32_t c)
        {
            if (!validIdx(a)||!validIdx(b)||!validIdx(c)) return;
            if (a==b||b==c||c==a) return;
            addEdge(mesh,edgeSet,a,b);
            addEdge(mesh,edgeSet,b,c);
            addEdge(mesh,edgeSet,c,a);
            ++mesh.trianglePrimitives;
        }

        void emitQuad(DecodedNsbmdMesh& mesh,
                      std::unordered_set<uint64_t>& edgeSet,
                      uint32_t a, uint32_t b, uint32_t c, uint32_t d)
        {
            if (!validIdx(a)||!validIdx(b)||!validIdx(c)||!validIdx(d)) return;
            if (a==b||b==c||c==d||d==a||a==c||b==d) return;
            addEdge(mesh,edgeSet,a,b);
            addEdge(mesh,edgeSet,b,c);
            addEdge(mesh,edgeSet,c,d);
            addEdge(mesh,edgeSet,d,a);
            ++mesh.quadPrimitives;
        }

        uint32_t pushVertex(DecodedNsbmdMesh& mesh, const QVector3D& v)
        {
            if (!plausibleVertex(v)) return UINT32_MAX;
            const auto idx = static_cast<uint32_t>(mesh.vertices.size());
            mesh.vertices.push_back(v);
            return idx;
        }

        // ------------------------------------------------------------------ //
        //  GX state machine                                                   //
        // ------------------------------------------------------------------ //

        struct GxState
        {
            QMatrix4x4              currentMtx;
            std::vector<QMatrix4x4> mtxStack;
            std::map<int,QMatrix4x4> mtxStored;

            // Persistent local-space vertex position (updated after each VTX cmd).
            QVector3D currentLocal {0.f, 0.f, 0.f};

            uint8_t  primitiveMode   = 0;
            bool     primitiveActive = false;
            std::vector<uint32_t> primVerts;

            GxState() { currentMtx.setToIdentity(); }
        };

        // Transform local-space vertex, push it to the mesh, wire up primitives.
        void emitVertex(DecodedNsbmdMesh& mesh,
                        std::unordered_set<uint64_t>& edgeSet,
                        GxState& state,
                        const QVector3D& local)
        {
            // Persist BEFORE the primitive check so the next partial command
            // (VTX_XY, VTX_DIFF …) sees the updated position.
            state.currentLocal = local;

            if (!state.primitiveActive) return;

            const QVector3D world = state.currentMtx.map(local);
            const uint32_t  idx   = pushVertex(mesh, world);
            if (!validIdx(idx)) return;

            state.primVerts.push_back(idx);
            const std::size_t n = state.primVerts.size();

            switch (state.primitiveMode & 0x3u)
            {
                case 0: // Separate triangles
                    if ((n % 3) == 0)
                        emitTriangle(mesh, edgeSet,
                            state.primVerts[n-3], state.primVerts[n-2], state.primVerts[n-1]);
                    break;

                case 1: // Separate quads
                    if ((n % 4) == 0)
                        emitQuad(mesh, edgeSet,
                            state.primVerts[n-4], state.primVerts[n-3],
                            state.primVerts[n-2], state.primVerts[n-1]);
                    break;

                case 2: // Triangle strip — winding alternates
                    if (n >= 3)
                    {
                        if ((n & 1u) == 1u)
                            emitTriangle(mesh, edgeSet,
                                state.primVerts[n-3], state.primVerts[n-2], state.primVerts[n-1]);
                        else
                            emitTriangle(mesh, edgeSet,
                                state.primVerts[n-2], state.primVerts[n-3], state.primVerts[n-1]);
                        ++mesh.triangleStripPrimitives;
                    }
                    break;

                case 3: // Quad strip — pairs of verts form connected quads
                    if (n >= 4 && (n % 2) == 0)
                    {
                        emitQuad(mesh, edgeSet,
                            state.primVerts[n-4], state.primVerts[n-3],
                            state.primVerts[n-1], state.primVerts[n-2]);
                        ++mesh.quadStripPrimitives;
                    }
                    break;
            }
        }

        // ------------------------------------------------------------------ //
        //  Matrix command execution                                           //
        // ------------------------------------------------------------------ //

        void execMatrixCmd(GxState& state,
                           const std::vector<uint8_t>& d,
                           std::size_t pc,
                           uint8_t cmd)
        {
            switch (cmd)
            {
                case 0x11: // MTX_PUSH
                    state.mtxStack.push_back(state.currentMtx);
                    break;

                case 0x12: // MTX_POP — 6-bit signed pop count
                {
                    int count = signExtend(readU32(d, pc) & 0x3fu, 6);
                    if (count < 1) count = 1;
                    while (count-- > 0 && !state.mtxStack.empty())
                    {
                        state.currentMtx = state.mtxStack.back();
                        state.mtxStack.pop_back();
                    }
                    break;
                }

                case 0x13: // MTX_STORE
                    state.mtxStored[static_cast<int>(readU32(d,pc)&0x1fu)] = state.currentMtx;
                    break;

                case 0x14: // MTX_RESTORE
                {
                    int idx = static_cast<int>(readU32(d,pc)&0x1fu);
                    auto it = state.mtxStored.find(idx);
                    if (it != state.mtxStored.end()) state.currentMtx = it->second;
                    break;
                }

                case 0x15: state.currentMtx.setToIdentity();                            break; // MTX_IDENTITY
                case 0x16: state.currentMtx  = matLoad4x4(d, pc);                       break; // MTX_LOAD_4x4
                case 0x17: state.currentMtx  = matLoad4x3(d, pc);                       break; // MTX_LOAD_4x3
                case 0x18: state.currentMtx  = state.currentMtx * matLoad4x4(d, pc);   break; // MTX_MULT_4x4
                case 0x19: state.currentMtx  = state.currentMtx * matLoad4x3(d, pc);   break; // MTX_MULT_4x3
                case 0x1A: state.currentMtx  = state.currentMtx * matLoad3x3(d, pc);   break; // MTX_MULT_3x3
                case 0x1B: state.currentMtx  = state.currentMtx * matScale(d, pc);      break; // MTX_SCALE
                case 0x1C: state.currentMtx  = state.currentMtx * matTranslate(d, pc); break; // MTX_TRANS
                default:   break;
            }
        }

        // ------------------------------------------------------------------ //
        //  Full GX command dispatch                                           //
        // ------------------------------------------------------------------ //

        void execGxCmd(DecodedNsbmdMesh& mesh,
                       std::unordered_set<uint64_t>& edgeSet,
                       GxState& state,
                       const std::vector<uint8_t>& d,
                       std::size_t pc,
                       uint8_t cmd)
        {
            if (cmd >= 0x11 && cmd <= 0x1C)
            {
                ++mesh.matrixCommands;
                execMatrixCmd(state, d, pc, cmd);
                return;
            }

            switch (cmd)
            {
                case 0x40: // BEGIN_VTXS
                    state.primitiveMode = static_cast<uint8_t>(readU32(d, pc) & 0x3u);
                    state.primVerts.clear();
                    state.primitiveActive = true;
                    ++mesh.beginCommands;
                    break;

                case 0x41: // END_VTXS
                    state.primVerts.clear();
                    state.primitiveActive = false;
                    ++mesh.endCommands;
                    break;

                case 0x23: // VTX_16 — full 16-bit signed, 1/4096
                {
                    const uint32_t w0 = readU32(d, pc);
                    const uint32_t w1 = readU32(d, pc+4);
                    emitVertex(mesh, edgeSet, state, QVector3D(
                        fx12h(static_cast<uint16_t>( w0        & 0xffffu)),
                        fx12h(static_cast<uint16_t>((w0 >> 16) & 0xffffu)),
                        fx12h(static_cast<uint16_t>( w1        & 0xffffu))));
                    ++mesh.vertexCommands;
                    break;
                }

                case 0x24: // VTX_10 — 10-bit signed, 1/64
                {
                    const uint32_t w = readU32(d, pc);
                    emitVertex(mesh, edgeSet, state, QVector3D(
                        static_cast<float>(signExtend( w        & 0x3ffu, 10)) * kFx6,
                        static_cast<float>(signExtend((w >> 10) & 0x3ffu, 10)) * kFx6,
                        static_cast<float>(signExtend((w >> 20) & 0x3ffu, 10)) * kFx6));
                    ++mesh.vertexCommands;
                    break;
                }

                case 0x25: // VTX_XY — update X, Y; reuse Z
                {
                    const uint32_t w = readU32(d, pc);
                    QVector3D v = state.currentLocal;
                    v.setX(fx12h(static_cast<uint16_t>( w        & 0xffffu)));
                    v.setY(fx12h(static_cast<uint16_t>((w >> 16) & 0xffffu)));
                    emitVertex(mesh, edgeSet, state, v);
                    ++mesh.vertexCommands;
                    break;
                }

                case 0x26: // VTX_XZ — update X, Z; reuse Y
                {
                    const uint32_t w = readU32(d, pc);
                    QVector3D v = state.currentLocal;
                    v.setX(fx12h(static_cast<uint16_t>( w        & 0xffffu)));
                    v.setZ(fx12h(static_cast<uint16_t>((w >> 16) & 0xffffu)));
                    emitVertex(mesh, edgeSet, state, v);
                    ++mesh.vertexCommands;
                    break;
                }

                case 0x27: // VTX_YZ — update Y, Z; reuse X
                {
                    const uint32_t w = readU32(d, pc);
                    QVector3D v = state.currentLocal;
                    v.setY(fx12h(static_cast<uint16_t>( w        & 0xffffu)));
                    v.setZ(fx12h(static_cast<uint16_t>((w >> 16) & 0xffffu)));
                    emitVertex(mesh, edgeSet, state, v);
                    ++mesh.vertexCommands;
                    break;
                }

                case 0x28: // VTX_DIFF — 10-bit signed delta, unit = 1/(4096*8)
                {
                    const uint32_t w = readU32(d, pc);
                    const QVector3D delta(
                        static_cast<float>(signExtend( w        & 0x3ffu, 10)) * kFxDiff,
                        static_cast<float>(signExtend((w >> 10) & 0x3ffu, 10)) * kFxDiff,
                        static_cast<float>(signExtend((w >> 20) & 0x3ffu, 10)) * kFxDiff);
                    emitVertex(mesh, edgeSet, state, state.currentLocal + delta);
                    ++mesh.vertexCommands;
                    break;
                }

                default:
                    break;
            }
        }

        // ------------------------------------------------------------------ //
        //  Display-list runner                                                //
        // ------------------------------------------------------------------ //

        void runDisplayList(DecodedNsbmdMesh& mesh,
                            std::unordered_set<uint64_t>& edgeSet,
                            GxState& state,
                            const std::vector<uint8_t>& d,
                            std::size_t start,
                            std::size_t end)
        {
            std::size_t pc = start;

            while (pc + 4 <= end &&
                   mesh.commandWordsSeen < kMaxCommandWords &&
                   mesh.vertices.size() < kMaxVertices)
            {
                const uint32_t packed = readU32(d, pc);
                pc += 4;
                ++mesh.commandWordsSeen;

                const uint8_t cmds[4] = {
                    static_cast<uint8_t>( packed        & 0xffu),
                    static_cast<uint8_t>((packed >>  8) & 0xffu),
                    static_cast<uint8_t>((packed >> 16) & 0xffu),
                    static_cast<uint8_t>((packed >> 24) & 0xffu)
                };

                // All-zero packing words are no-ops.
                if (!cmds[0] && !cmds[1] && !cmds[2] && !cmds[3]) continue;

                for (uint8_t cmd : cmds)
                {
                    if (cmd == 0x00) continue;

                    const int words = commandArgWords(cmd);
                    if (words < 0)
                    {
                        ++mesh.unsupportedCommands;
                        // Abort early only if we haven't seen any geometry yet.
                        if (mesh.unsupportedCommands > 64 && mesh.vertices.empty())
                            return;
                        continue;
                    }

                    if (!canRead(d, pc, static_cast<std::size_t>(words)*4u))
                        return;

                    execGxCmd(mesh, edgeSet, state, d, pc, cmd);
                    pc += static_cast<std::size_t>(words)*4u;
                }
            }
        }

        // ------------------------------------------------------------------ //
        //  MDL0 structure parser                                              //
        // ------------------------------------------------------------------ //
        //
        // Nitro dictionary format (NSBMD model / polygon tables):
        //   +0x00  uint32  entry count
        //   +0x04  uint32  padding / unknown
        //   +0x08  entries[count]:  each 8 bytes
        //            +0x00  uint16  id (unused here)
        //            +0x02  uint16  padding
        //            +0x04  uint32  offset of data block relative to dict base
        //
        // Model data block (relative offsets into block):
        //   +0x38  uint32  offset to polygon dictionary (relative to block base)
        //
        // Polygon data block:
        //   +0x00  uint32  offset to display list (relative to block base)
        //   +0x04  uint32  display-list size in bytes

        struct DlRegion { std::size_t start = 0; std::size_t size = 0; };

        std::vector<std::size_t> parseDictionary(const std::vector<uint8_t>& d,
                                                 std::size_t dictAbs)
        {
            std::vector<std::size_t> result;
            if (!canRead(d, dictAbs, 8)) return result;

            const uint32_t count = readU32(d, dictAbs);
            if (count == 0 || count > 256) return result;

            for (uint32_t i = 0; i < count; ++i)
            {
                const std::size_t entBase = dictAbs + 8u + static_cast<std::size_t>(i)*8u;
                if (!canRead(d, entBase, 8)) break;
                const uint32_t relOff = readU32(d, entBase + 4u);
                result.push_back(dictAbs + relOff);
            }
            return result;
        }

        std::vector<DlRegion> extractDlRegions(const std::vector<uint8_t>& d,
                                               std::size_t mdl0Off,
                                               std::size_t mdl0End)
        {
            std::vector<DlRegion> regions;
            if (!canRead(d, mdl0Off, 12)) return regions;

            const uint32_t    modelTableRel = readU32(d, mdl0Off + 8u);
            const std::size_t modelTableAbs = mdl0Off + modelTableRel;

            for (std::size_t modelAbs : parseDictionary(d, modelTableAbs))
            {
                if (!canRead(d, modelAbs, 0x40)) continue;

                const uint32_t    polyTableRel = readU32(d, modelAbs + 0x38u);
                const std::size_t polyTableAbs = modelAbs + polyTableRel;

                for (std::size_t polyAbs : parseDictionary(d, polyTableAbs))
                {
                    if (!canRead(d, polyAbs, 8)) continue;

                    const uint32_t dlRel  = readU32(d, polyAbs);
                    const uint32_t dlSize = readU32(d, polyAbs + 4u);

                    if (dlSize == 0 || dlSize > 0x200000u) continue;

                    const std::size_t dlAbs = polyAbs + dlRel;
                    if (dlAbs + dlSize > d.size())    continue;
                    if (dlAbs < mdl0Off || dlAbs >= mdl0End) continue;

                    regions.push_back({dlAbs, dlSize});
                }
            }
            return regions;
        }

        // Fallback: scan for packed words containing BEGIN_VTXS (0x40).
        std::vector<DlRegion> heuristicScan(const std::vector<uint8_t>& d,
                                            std::size_t scanStart,
                                            std::size_t scanEnd)
        {
            std::set<std::size_t> candidates;

            for (std::size_t off = scanStart; off + 4 < scanEnd; off += 4)
            {
                const uint32_t w = readU32(d, off);
                const bool hasBegin =
                    (( w        & 0xffu) == 0x40u) ||
                    (((w >>  8) & 0xffu) == 0x40u) ||
                    (((w >> 16) & 0xffu) == 0x40u) ||
                    (((w >> 24) & 0xffu) == 0x40u);
                if (!hasBegin) continue;

                const std::size_t lo = off > 256u ? off - 256u : scanStart;
                for (std::size_t base = lo; base <= off; base += 4)
                    candidates.insert(base);

                if (candidates.size() > 512) break;
            }

            std::vector<DlRegion> regions;
            for (std::size_t base : candidates)
            {
                const std::size_t rEnd = std::min(scanEnd, base + 256u*1024u);
                regions.push_back({base, rEnd - base});
            }
            return regions;
        }

        // Finalise bounding box + diagnostics; set mesh.valid.
        void finaliseMesh(DecodedNsbmdMesh& mesh)
        {
            if (mesh.vertices.size() < 3 || mesh.edges.empty() || mesh.beginCommands == 0)
                return;

            mesh.minBounds = mesh.vertices.front();
            mesh.maxBounds = mesh.vertices.front();
            for (const QVector3D& v : mesh.vertices)
            {
                mesh.minBounds.setX(std::min(mesh.minBounds.x(), v.x()));
                mesh.minBounds.setY(std::min(mesh.minBounds.y(), v.y()));
                mesh.minBounds.setZ(std::min(mesh.minBounds.z(), v.z()));
                mesh.maxBounds.setX(std::max(mesh.maxBounds.x(), v.x()));
                mesh.maxBounds.setY(std::max(mesh.maxBounds.y(), v.y()));
                mesh.maxBounds.setZ(std::max(mesh.maxBounds.z(), v.z()));
            }

            const QVector3D extent = mesh.maxBounds - mesh.minBounds;
            const float largest = std::max({std::abs(extent.x()),
                                            std::abs(extent.y()),
                                            std::abs(extent.z())});
            if (!std::isfinite(largest) || largest <= 0.0001f || largest > 100000.f)
                return;

            if (mesh.edges.size() > mesh.vertices.size() * 8)
                mesh.edges.resize(mesh.vertices.size() * 8);

            std::ostringstream ss;
            ss << "cmdWords="       << mesh.commandWordsSeen
               << " begin="         << mesh.beginCommands
               << " end="           << mesh.endCommands
               << " vtxCmds="       << mesh.vertexCommands
               << " mtx="           << mesh.matrixCommands
               << " unsupported="   << mesh.unsupportedCommands
               << " tri="           << mesh.trianglePrimitives
               << " quad="          << mesh.quadPrimitives
               << " triStrip="      << mesh.triangleStripPrimitives
               << " quadStrip="     << mesh.quadStripPrimitives;
            mesh.diagnostics = ss.str();
            mesh.valid = true;
        }

        std::vector<uint8_t> readAll(const std::filesystem::path& path)
        {
            std::ifstream f(path, std::ios::binary);
            if (!f) throw std::runtime_error("failed to open " + path.string());
            return {std::istreambuf_iterator<char>(f), {}};
        }

    } // namespace (anonymous)

    // ======================================================================= //
    //  Public API                                                              //
    // ======================================================================= //

    DecodedNsbmdMesh NsbmdGeometryDecoder::decodeWireframeMesh(
        const std::filesystem::path& path)
    {
        try
        {
            const auto data = readAll(path);
            if (data.size() < 0x20) return {};

            const std::string magic(reinterpret_cast<const char*>(data.data()), 4);
            if (magic != "BMD0" && magic != "BDL0") return {};

            // Build section-offset table.
            const uint16_t sectionCount = readU16(data, 0x0eu);
            std::vector<uint32_t> sectionOffsets;
            sectionOffsets.reserve(sectionCount);
            for (uint16_t i = 0; i < sectionCount; ++i)
            {
                const std::size_t off = 0x10u + static_cast<std::size_t>(i)*4u;
                if (canRead(data, off, 4))
                    sectionOffsets.push_back(readU32(data, off));
            }

            // Locate MDL0.
            std::size_t mdl0Off = std::string::npos;
            std::size_t mdl0End = data.size();
            for (uint32_t off : sectionOffsets)
            {
                if (!canRead(data, off, 4)) continue;
                if (std::string(reinterpret_cast<const char*>(data.data()+off), 4) == "MDL0")
                {
                    mdl0Off = off;
                    for (uint32_t other : sectionOffsets)
                        if (other > mdl0Off)
                            mdl0End = std::min(mdl0End, static_cast<std::size_t>(other));
                    break;
                }
            }

            if (mdl0Off == std::string::npos || mdl0End <= mdl0Off + 8)
                return {};

            // --- Phase 1: structured MDL0 parse ---
            auto regions = extractDlRegions(data, mdl0Off, mdl0End);

            // --- Phase 2: heuristic fallback ---
            if (regions.empty())
            {
                core::Logger::warning(
                    "MDL0 polygon-table parse yielded no DL regions; "
                    "using heuristic scan: " + path.filename().string());
                regions = heuristicScan(data, mdl0Off, mdl0End);
            }

            if (regions.empty()) return {};

            // Score heuristic: prefer structurally complete meshes.
            auto score = [](const DecodedNsbmdMesh& m) -> std::size_t {
                return m.vertices.size()     * 2u
                     + m.edges.size()
                     + m.beginCommands       * 30u
                     + m.trianglePrimitives  *  5u
                     + m.quadPrimitives      *  5u
                     + m.matrixCommands      *  2u;
            };

            DecodedNsbmdMesh best;

            for (const DlRegion& r : regions)
            {
                DecodedNsbmdMesh mesh;
                GxState state;
                std::unordered_set<uint64_t> edgeSet;

                runDisplayList(mesh, edgeSet, state, data, r.start, r.start + r.size);
                finaliseMesh(mesh);

                if (mesh.valid && score(mesh) > score(best))
                    best = std::move(mesh);
            }

            if (best.valid)
                core::Logger::info(
                    "Decoded GX NSBMD wire mesh: " + path.filename().string() +
                    " vertices=" + std::to_string(best.vertices.size()) +
                    " edges="    + std::to_string(best.edges.size()) +
                    " "          + best.diagnostics);
            else
                core::Logger::warning(
                    "No GX display-list vertices decoded from NSBMD: " +
                    path.filename().string());

            return best;
        }
        catch (const std::exception& e)
        {
            core::Logger::error(std::string("NSBMD geometry decode failed: ") + e.what());
            return {};
        }
    }

} // namespace nitro
