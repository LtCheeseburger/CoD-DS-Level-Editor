#pragma once

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

#include <QVector3D>

namespace nitro
{
    struct DecodedNsbmdEdge
    {
        std::uint32_t a = 0;
        std::uint32_t b = 0;
    };

    struct DecodedNsbmdMesh
    {
        bool valid = false;
        bool experimental = true;
        std::vector<QVector3D> vertices;
        std::vector<DecodedNsbmdEdge> edges;
        QVector3D minBounds {0.0f, 0.0f, 0.0f};
        QVector3D maxBounds {0.0f, 0.0f, 0.0f};

        std::uint32_t commandWordsSeen = 0;
        std::uint32_t beginCommands = 0;
        std::uint32_t endCommands = 0;
        std::uint32_t vertexCommands = 0;
        std::uint32_t matrixCommands = 0;
        std::uint32_t unsupportedCommands = 0;
        std::uint32_t trianglePrimitives = 0;
        std::uint32_t quadPrimitives = 0;
        std::uint32_t triangleStripPrimitives = 0;
        std::uint32_t quadStripPrimitives = 0;
        std::string diagnostics;
    };

    class NsbmdGeometryDecoder
    {
    public:
        // Experimental native NSBMD geometry decoder.
        // v0.1.2 adds a fuller GX command parser: packed commands, matrix stack, vertex state, and primitive modes:
        // triangles, quads, triangle strips, and quad strips.
        // This is still read-only and intentionally conservative.
        static DecodedNsbmdMesh decodeWireframeMesh(const std::filesystem::path& path);
    };
}
